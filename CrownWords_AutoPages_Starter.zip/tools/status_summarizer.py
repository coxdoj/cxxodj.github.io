import json, datetime, pathlib
p = pathlib.Path('lychee.json')
ok = 0; broken = 0; details = []
if p.exists():
    try:
        data = json.loads(p.read_text())
        for res in data.get('links', []):
            status = res.get('status','')
            if status == "Ok":
                ok += 1
            else:
                broken += 1
                details.append(f"- {res.get('link')} → {status}")
    except Exception as e:
        details.append(f"Parser error: {e}")
else:
    details.append("No lychee.json found.")
now = datetime.datetime.utcnow().strftime("%Y-%m-%d %H:%M UTC")
overall = "OK" if broken == 0 else ("WARN" if broken < 5 else "FAIL")
md = f"# Site Status\n\n- Last run: {now}\n- Overall: **{overall}**\n- Links OK: {ok}\n- Links Broken: {broken}\n\nDetails:\n" + ("\n".join(details[:50]) if details else "- None -")
pathlib.Path('STATUS.md').write_text(md)
print("STATUS.md updated")
