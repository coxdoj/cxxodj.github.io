# Site Status

This file is updated automatically by a scheduled workflow. Do not edit by hand.

- Last run: _pending_
- Overall: _unknown_

Artifacts:
- Link check: `lychee.json`
