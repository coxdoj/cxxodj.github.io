# CrownWords Auto Pages Starter

Self-checking GitHub Pages starter with:
- Push-to-deploy workflow
- 15‑minute scheduled health checks
- Link checker (lychee)
- Optional Super‑Linter
- Auto‑updated `STATUS.md`
- Dependabot for Actions updates

## Quick start
1. Create a repo (public). If you want the root domain use `cxxodj.github.io`. Otherwise any name.
2. Copy these files into the repo and commit to the `main` branch.
3. In **Settings → Pages**, set Source: `GitHub Actions`. Save.
4. Push once. The site will deploy.

### Notes
- Schedules cannot run every minute. Typical minimum is 5–15 minutes.
- Uncomment Super‑Linter in `status.yml` if you want full static linting.
